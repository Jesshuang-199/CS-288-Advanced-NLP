"""Multi-layer perceptron model for Assignment 1: Starter code.

You can change this code while keeping the function giving headers. You can add any functions that will help you. The given function headers are used for testing the code, so changing them will fail testing.


We adapt shape suffixes style when working with tensors.
See https://medium.com/@NoamShazeer/shape-suffixes-good-coding-style-f836e72e24fd.

Dimension key:

b: batch size
l: max sequence length
c: number of classes
v: vocabulary size

For example,

feature_b_l means a tensor of shape (b, l) == (batch_size, max_sequence_length).
length_1 means a tensor of shape (1) == (1,).
loss means a tensor of shape (). You can retrieve the loss value with loss.item().
"""

import argparse
import os
from collections import Counter
from pprint import pprint
from typing import Dict, List, Tuple
import re
import copy

import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm
from utils import DataPoint, DataType, accuracy, load_data, save_results


class Tokenizer:
    # The index of the padding embedding.
    # This is used to pad variable length sequences.
    TOK_PADDING_INDEX = 0
    STOP_WORDS = set(pd.read_csv("stopwords.txt", header=None)[0])

    def _pre_process_text(self, text: str) -> List[str]:
        processed = []
        for token in text.lower().split():
            # Break punctuation-heavy tokens (e.g. comp.sys.ibm.pc.hardware) into useful parts.
            token_parts = re.split(r"[^a-z0-9]+", token)
            for part in token_parts:
                if not part:
                    continue
                if self.remove_stop_words and part in self.STOP_WORDS:
                    continue
                processed.append(part)
        return processed

    def __init__(
        self,
        data: List[DataPoint],
        max_vocab_size: int = None,
        remove_stop_words: bool = True,
    ):
        self.remove_stop_words = remove_stop_words
        corpus = " ".join([d.text for d in data])
        token_freq = Counter(self._pre_process_text(corpus))
        token_freq = token_freq.most_common(max_vocab_size)
        tokens = [t for t, _ in token_freq]
        # offset because padding index is 0
        self.token2id = {t: (i + 1) for i, t in enumerate(tokens)}
        self.token2id["<PAD>"] = Tokenizer.TOK_PADDING_INDEX
        self.id2token = {i: t for t, i in self.token2id.items()}

    def tokenize(self, text: str) -> List[int]:
        token_ids = []
        for token in self._pre_process_text(text):
            if token in self.token2id:
                token_ids.append(self.token2id[token])
        return token_ids


def get_label_mappings(
    data: List[DataPoint],
) -> Tuple[Dict[str, int], Dict[int, str]]:
    """Reads the labels file and returns the mapping."""
    labels = list(set([d.label for d in data]))
    label2id = {label: index for index, label in enumerate(labels)}
    id2label = {index: label for index, label in enumerate(labels)}
    return label2id, id2label


class BOWDataset(Dataset):
    def __init__(
        self,
        data: List[DataPoint],
        tokenizer: Tokenizer,
        label2id: Dict[str, int],
        max_length: int = 100,
    ):
        super().__init__()
        self.data = data
        self.tokenizer = tokenizer
        self.label2id = label2id
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def __getitem__(
        self, idx: int
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Returns a single example as a tuple of torch.Tensors.
        features_l: The tokenized text of example, shaped (max_length,)
        length: The length of the text, shaped ()
        label: The label of the example, shaped ()

        All of have type torch.int64.
        """
        dp: DataPoint = self.data[idx]
        token_ids = self.tokenizer.tokenize(dp.text)[: self.max_length]
        length = len(token_ids)

        if length < self.max_length:
            token_ids = token_ids + [Tokenizer.TOK_PADDING_INDEX] * (
                self.max_length - length
            )

        if dp.label is None:
            label_id = 0
        else:
            label_id = self.label2id[dp.label]

        return (
            torch.tensor(token_ids, dtype=torch.int64),
            torch.tensor(length, dtype=torch.int64),
            torch.tensor(label_id, dtype=torch.int64),
        )


class MultilayerPerceptronModel(nn.Module):
    """Multi-layer perceptron model for classification."""

    def __init__(self, vocab_size: int, num_classes: int, padding_index: int):
        """Initializes the model.

        Inputs:
            num_classes (int): The number of classes.
            vocab_size (int): The size of the vocabulary.
        """
        super().__init__()
        self.padding_index = padding_index
        self.embedding = nn.Embedding(
            num_embeddings=vocab_size,
            embedding_dim=128,
            padding_idx=padding_index,
        )
        self.hidden1 = nn.Linear(128, 256)
        self.hidden2 = nn.Linear(256, 128)
        self.output = nn.Linear(128, num_classes)
        self.dropout = nn.Dropout(0.2)

    def forward(
        self, input_features_b_l: torch.Tensor, input_length_b: torch.Tensor
    ) -> torch.Tensor:
        """Forward pass of the model.

        Inputs:
            input_features_b_l (tensor): Input data for an example or a batch of examples.
            input_length (tensor): The length of the input data.

        Returns:
            output_b_c: The output of the model.
        """
        emb_b_l_e = self.embedding(input_features_b_l)
        mask_b_l = (
            input_features_b_l != self.padding_index
        ).unsqueeze(-1)
        masked_emb_b_l_e = emb_b_l_e * mask_b_l

        summed_b_e = masked_emb_b_l_e.sum(dim=1)
        length_b_1 = input_length_b.clamp(min=1).unsqueeze(1).float()
        nbow_b_e = summed_b_e / length_b_1

        hidden_b_h = torch.relu(self.hidden1(nbow_b_e))
        hidden_b_h = self.dropout(hidden_b_h)
        hidden_b_h = torch.tanh(self.hidden2(hidden_b_h))
        output_b_c = self.output(hidden_b_h)
        return output_b_c


class Trainer:
    def __init__(self, model: nn.Module):
        self.model = model
        self.device = next(self.model.parameters()).device

    def predict(self, data: BOWDataset) -> List[int]:
        """Predicts a label for an input.

        Inputs:
            model_input (tensor): Input data for an example or a batch of examples.

        Returns:
            The predicted class.

        """
        all_predictions = []
        dataloader = DataLoader(data, batch_size=32, shuffle=False)
        self.model.eval()
        with torch.no_grad():
            for inputs_b_l, lengths_b, _ in dataloader:
                inputs_b_l = inputs_b_l.to(self.device)
                lengths_b = lengths_b.to(self.device)
                logits_b_c = self.model(inputs_b_l, lengths_b)
                preds_b = torch.argmax(logits_b_c, dim=1)
                all_predictions.extend(preds_b.cpu().tolist())
        return all_predictions

    def evaluate(self, data: BOWDataset) -> float:
        """Evaluates the model on a dataset.

        Inputs:
            data: The dataset to evaluate on.

        Returns:
            The accuracy of the model.
        """
        predictions = self.predict(data)
        targets = [data.label2id[dp.label] for dp in data.data if dp.label is not None]
        return accuracy(predictions, targets)

    def train(
        self,
        training_data: BOWDataset,
        val_data: BOWDataset,
        optimizer: torch.optim.Optimizer,
        num_epochs: int,
    ) -> None:
        """Trains the MLP.

        Inputs:
            training_data: Suggested type for an individual training example is
                an (input, label) pair or (input, id, label) tuple.
                You can also use a dataloader.
            val_data: Validation data.
            optimizer: The optimization method.
            num_epochs: The number of training epochs.
        """
        torch.manual_seed(0)
        criterion = nn.CrossEntropyLoss()
        best_val_acc = -1.0
        best_state_dict = None
        for epoch in range(num_epochs):
            self.model.train()
            total_loss = 0
            dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
            for inputs_b_l, lengths_b, labels_b in tqdm(dataloader):
                inputs_b_l = inputs_b_l.to(self.device)
                lengths_b = lengths_b.to(self.device)
                labels_b = labels_b.to(self.device)

                optimizer.zero_grad()
                logits_b_c = self.model(inputs_b_l, lengths_b)
                loss = criterion(logits_b_c, labels_b)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                optimizer.step()
                total_loss += loss.item() * labels_b.shape[0]
            per_dp_loss = total_loss / len(training_data)

            self.model.eval()
            val_acc = self.evaluate(val_data)
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                best_state_dict = copy.deepcopy(self.model.state_dict())

            print(
                f"Epoch: {epoch + 1:<2} | Loss: {per_dp_loss:.2f} | Val accuracy: {100 * val_acc:.2f}%"
            )

        if best_state_dict is not None:
            self.model.load_state_dict(best_state_dict)
            print(
                f"Loaded best checkpoint with val accuracy: {100 * best_val_acc:.2f}%"
            )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="MultiLayerPerceptron model")
    parser.add_argument(
        "-d",
        "--data",
        type=str,
        default="sst2",
        help="Data source, one of ('sst2', 'newsgroups')",
    )
    parser.add_argument(
        "-e", "--epochs", type=int, default=3, help="Number of epochs"
    )
    parser.add_argument(
        "-l", "--learning_rate", type=float, default=0.001, help="Learning rate"
    )
    args = parser.parse_args()

    num_epochs = args.epochs
    lr = args.learning_rate
    data_type = DataType(args.data)

    train_data, val_data, dev_data, test_data = load_data(data_type)

    if data_type == DataType.NEWSGROUPS:
        tokenizer = Tokenizer(
            train_data, max_vocab_size=50000, remove_stop_words=True
        )
        max_length = 300
        if args.epochs == 3:
            num_epochs = 12
        if args.learning_rate == 0.001:
            lr = 0.001
    else:
        tokenizer = Tokenizer(
            train_data, max_vocab_size=30000, remove_stop_words=False
        )
        max_length = 120
        if args.epochs == 3:
            num_epochs = 8
    label2id, id2label = get_label_mappings(train_data)
    print("Id to label mapping:")
    pprint(id2label)

    train_ds = BOWDataset(train_data, tokenizer, label2id, max_length)
    val_ds = BOWDataset(val_data, tokenizer, label2id, max_length)
    dev_ds = BOWDataset(dev_data, tokenizer, label2id, max_length)
    test_ds = BOWDataset(test_data, tokenizer, label2id, max_length)

    model = MultilayerPerceptronModel(
        vocab_size=len(tokenizer.token2id),
        num_classes=len(label2id),
        padding_index=Tokenizer.TOK_PADDING_INDEX,
    )
    if torch.cuda.is_available():
        model = model.to("cuda")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        model = model.to("mps")

    trainer = Trainer(model)

    print("Training the model...")
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-5)
    trainer.train(train_ds, val_ds, optimizer, num_epochs)

    # Evaluate on dev
    dev_acc = trainer.evaluate(dev_ds)
    print(f"Development accuracy: {100 * dev_acc:.2f}%")

    # Predict on test
    test_preds = trainer.predict(test_ds)
    test_preds = [id2label[pred] for pred in test_preds]
    save_results(
        test_data,
        test_preds,
        os.path.join("results", f"mlp_{args.data}_test_predictions.csv"),
    )
